package sorvetes;

/**
 *
 * @author Letícia
 */

public interface Venda {

    void comprar();
    double getValor();
}
